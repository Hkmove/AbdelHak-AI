package com.abdelhak.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val BACKEND_URL = "https://YOUR-BACKEND-DOMAIN.example/chat"

data class ChatMessage(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AbdelHakApp() }
    }
}

@Composable
fun AbdelHakApp() {
    val bg = Color(0xFF090D19)
    val panel = Color(0xFF151D31)
    val accent = Color(0xFF756BFF)
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf(ChatMessage("assistant", "مرحباً! أنا AbdelHak AI. كيف يمكنني مساعدتك اليوم؟")) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = accent, background = bg, surface = panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(bg).padding(16.dp)) {
            Text("AbdelHak AI", color = Color.White, fontSize = 26.sp)
            Text("مساعدك الذكي", color = Color(0xFF9BA8C7), fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages) { msg ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                        Surface(color = if (msg.role == "user") Color(0xFF34305F) else panel,
                            shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                            Text(msg.text, Modifier.padding(13.dp), color = Color.White, fontSize = 15.sp)
                        }
                    }
                }
                if (busy) item { Text("AbdelHak AI يكتب...", color = Color(0xFFB9B4FF)) }
            }
            error?.let { Text(it, color = Color(0xFFFF8A8A), fontSize = 12.sp) }
            Row(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(18.dp)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f).padding(10.dp), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                    decorationBox = { inner -> if (input.isEmpty()) Text("اكتب رسالتك هنا...", color = Color.Gray); inner() })
                Button(enabled = input.isNotBlank() && !busy, onClick = {
                    val prompt = input.trim()
                    input = ""
                    messages.add(ChatMessage("user", prompt))
                    error = null
                    busy = true
                    scope.launch {
                        try {
                            val answer = withContext(Dispatchers.IO) { sendToBackend(messages.dropLast(1), prompt) }
                            messages.add(ChatMessage("assistant", answer))
                        } catch (e: Exception) {
                            error = "تعذر الاتصال بالخادم. تأكد من إعداد الخادم ورابطه."
                        } finally { busy = false }
                    }
                }) { Text("إرسال") }
            }
            Spacer(Modifier.height(6.dp))
            Text("نسخة أولية — يلزم ربط خادم الذكاء الاصطناعي", color = Color(0xFF7885A5), fontSize = 10.sp)
        }
    }
}

private fun sendToBackend(history: List<ChatMessage>, prompt: String): String {
    val connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
    }
    val all = JSONArray()
    history.filter { it.role == "user" || it.role == "assistant" }.forEach {
        all.put(JSONObject().put("role", it.role).put("content", it.text))
    }
    all.put(JSONObject().put("role", "user").put("content", prompt))
    val body = JSONObject().put("messages", all).toString()
    connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    val code = connection.responseCode
    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
    val response = stream.bufferedReader().use { it.readText() }
    connection.disconnect()
    if (code !in 200..299) throw IllegalStateException("Backend error: $code")
    return JSONObject(response).optString("reply", "لم يصل رد من الخادم.")
}
