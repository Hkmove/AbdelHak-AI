import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "1mb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 20 }));

app.get("/health", (_req, res) => res.json({ status: "ok", app: "AbdelHak AI" }));

app.post("/chat", async (req, res) => {
  try {
    const messages = req.body?.messages;
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "messages is required" });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "AI service is not configured" });
    }

    const safeMessages = messages.slice(-20).map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content ?? "").slice(0, 8000)
    }));

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "You are AbdelHak AI, a helpful, accurate multilingual assistant. Reply in the language used by the user.",
        input: safeMessages
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("AI provider error:", data);
      return res.status(502).json({ error: "AI provider request failed" });
    }
    const reply = (data.output || [])
      .flatMap(item => item.content || [])
      .filter(item => item.type === "output_text")
      .map(item => item.text)
      .join("\n");
    return res.json({ reply: reply || "لم أتمكن من إنشاء إجابة." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Internal server error" });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AbdelHak AI backend listening on ${port}`));
